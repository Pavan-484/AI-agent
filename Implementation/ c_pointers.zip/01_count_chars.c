#include <stdio.h>
int main() {
    char str[100];
    int count = 0;
    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);
    for (char *p = str; *p != '\0'; p++) {
        count++;
    }
    printf("Number of characters = %d\n", count - 1); // -1 to exclude newline
    return 0;
}
