#include <stdio.h>
#include <string.h>
int main() {
    char str[100], *p, *q, temp;
    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);
    int len = strlen(str);
    if (str[len - 1] == '\n') str[len - 1] = '\0'; // remove newline
    p = str;
    q = str + strlen(str) - 1;
    while (p < q) {
        temp = *p;
        *p = *q;
        *q = temp;
        p++;
        q--;
    }
    printf("Reversed String: %s\n", str);
    return 0;
}
