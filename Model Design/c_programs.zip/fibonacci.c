#include <stdio.h>
void fibonacciSeries(int n) {
    int a = 0, b = 1, next;
    for (int i = 0; i < n; i++) {
        printf("%d ", a);
        next = a + b;
        a = b;
        b = next;
    }
}
int fibonacciNth(int n) {
    if (n <= 1) return n;
    return fibonacciNth(n - 1) + fibonacciNth(n - 2);
}
int main() {
    int n;
    printf("Enter n: ");
    scanf("%d", &n);
    printf("Fibonacci series: ");
    fibonacciSeries(n);
    printf("\n%dth Fibonacci number is %d\n", n, fibonacciNth(n));
    return 0;
}