#include <stdio.h>
int findMax(int arr[], int n) {
    if (n == 1) return arr[0];
    int max = findMax(arr, n - 1);
    return (arr[n - 1] > max) ? arr[n - 1] : max;
}
int main() {
    int arr[] = {5, 1, 9, 2, 7};
    int n = sizeof(arr)/sizeof(arr[0]);
    printf("Max element is %d\n", findMax(arr, n));
    return 0;
}