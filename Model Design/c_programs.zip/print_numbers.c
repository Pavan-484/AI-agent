#include <stdio.h>
void printAsc(int n) {
    if (n == 0) return;
    printAsc(n - 1);
    printf("%d ", n);
}
void printDesc(int n) {
    if (n == 0) return;
    printf("%d ", n);
    printDesc(n - 1);
}
int main() {
    int n;
    printf("Enter n: ");
    scanf("%d", &n);
    printf("Numbers from 1 to %d: ", n);
    printAsc(n);
    printf("\nNumbers from %d to 1: ", n);
    printDesc(n);
    return 0;
}