#include <stdio.h>
int sum(int n) {
    return n * (n + 1) / 2;
}
int main() {
    int n;
    printf("Enter n: ");
    scanf("%d", &n);
    printf("Sum of first %d natural numbers is %d\n", n, sum(n));
    return 0;
}