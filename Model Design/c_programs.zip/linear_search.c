#include <stdio.h>
int linearSearch(int arr[], int n, int key, int i) {
    if (i >= n) return -1;
    if (arr[i] == key) return i;
    return linearSearch(arr, n, key, i + 1);
}
int main() {
    int arr[] = {4, 2, 5, 1, 9};
    int n = sizeof(arr)/sizeof(arr[0]);
    int key = 5;
    int index = linearSearch(arr, n, key, 0);
    if (index != -1)
        printf("Found at index %d\n", index);
    else
        printf("Not found\n");
    return 0;
}